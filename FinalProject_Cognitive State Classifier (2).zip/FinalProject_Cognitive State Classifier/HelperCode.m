% University of Florida, Herbert Wertheim College of Engineering
% J. Crayton Pruitt Department of Biomedical Engineering
% BME 3508 - Biomedical Signals and Systems - Fall 2021
% Copyright 2021 Dr. Mansy
%
% Final Project Helper Code
% ---------------------------------------

% Load trainnig data
load('EyesOpenClosed_Training.mat');
dataset = EyesOpenClosed_Training; %define dataset (change this depending on Training or Testing)
num_windows = 32; %define number of windows of data (Training has 32 windows, Testing has 62 windows)
window_duration= 23.6; %seconds

%%%% 1.a TO DO %%%%%%%%
% Calculate the sampling frequency of the dataset
% fs = ?;
%%%%%%%%%%%%%%%%%%%

%% Concatenate data windows together
% change labels of C and O into numerical values (C=1, O=0) 
for i = 1:num_windows
    if strcmpi(dataset(2,i),'C')==1 %if closed
        dataset{2,i} = 1;
    end
    if strcmpi(dataset(2,i),'O')==1 %if open
        dataset{2,i} = 0;
    end
end

% Concatenate windows 
concat = []; %initialize array for concatenated data
labels = []; %initialize array for concatenated labels (C=1, O=0)
for i = 1:num_windows 
    concat = vertcat(concat,dataset{1,i});
    labels = vertcat(labels,repmat(dataset{2,i},length(dataset{1,i}),1)); 
end


%%%% 1.b TO DO %%%%%%%%
% Plot the concatenated signal and overlay a square wave that shows portion
% of C vs O. Makre sure the x-axis represents time not number of sample



%% 1.c Separate data into Eyes Open and Eyes Closed 
%%%% 1.d TO DO %%%%%%%%
% Calculate the mean of each EyesClosed and EyesOpen window and
% concatinate them
EyesOpen = [];
EyesClosed = [];
for i = 1:num_windows
    if dataset{2,i} == 1 % closed
        EyesClosed = vertcat(EyesClosed,dataset{1,i});
        %
    end
    if dataset{2,i} == 0 % open
        EyesOpen = vertcat(EyesOpen,dataset{1,i});
        %
    end
end
%%%% 1.d TO DO %%%%%%%%
% Plot the concatinated means and stds for each condition


%%%% 1.e TO DO %%%%%%%%
% Plot the smoothed concatinated means adn stds for each condition


%% 1.f Calculate the mean and standard deviation (std) of the time series of each condition.
mean(EyesClosed)
std(EyesClosed)
mean(EyesOpen)
std(EyesOpen)



%% Calculate the magnitude spectrum and PSD using FFT function
set = EyesClosed; %define dataset (EyesClosed or EyesOpen) 

% FFT 
L = length(set); %length of dataset 
T = 1/fs; %period (seconds)
Y = fft(set); %perform FFT 
f = fs*(0:(L/2))/L; %frequencies 

P2 = abs(Y/L); %double-sided magnitude spectra
P1 = P2(1:L/2+1); %single-sided magnitude spectrum
P1(2:end-1) = 2*P1(2:end-1);

%%%% 1.g TO DO %%%%%%%%
% Calculate the single-sided Power Spectrum
P = ??; % single-sided Power spectrum (PSD)

%%%% 1.g TO DO %%%%%%%%
% plot the single-sided magnitude spectrum and PSD
figure;
plot(P1,f)
title('Add Title Please') 
xlabel('Add xLabel Please')
ylabel('Add yLabel Please')

%%%%%%%%%%%%%%%%%%%
% Plot the spectogram of the concatenated data (con_data) and 
% compare it to the labels squarewave 
figure, spectrogram(concat,floor(fs*2),floor(fs*1),1024,fs,'yaxis'); colormap jet, caxis([-60 50])


%% 2. Data Conditioning (Filtering )

filt_order = ??; %define filter order 
filt_cutoff = ??; %define filter cutoff frequency
set = EyesClosed; %define dataset (EyesClosed or EyesOpen) 

% Butterworth lowpass filter 
[b, a] = butter(filt_order,filt_cutoff/(fs/2),'low');

filtered_data = filtfilt(b,a,set); %apply the filter to data  

%%%% TO DO %%%%%%%%
% 2.a+b plot the magnitude spectrum or PSD using FFT function
% of the filtered data

%% 3. Implement the classifier 

dataset = EyesOpenClosed_Training; %define dataset (change this depending on Training or Testing)

%%%% 3.a TO DO %%%%%%%%%
% Identify the range of frequencies that correspond to the alpha-band and 
% determine a power threshold to distinguish between C and O conditions 
%%%%%%%%%%%%%%%%%%%%

% loop thorugh windowed data and classify as C or O 
for i = 1:num_windows
    
    % grab a window of data
    set = dataset{1,i}; 
    
    % compute FFT 
    L = length(set); %length of dataset 
    T = 1/fs; %period (seconds)
    Y = fft(set); %perform FFT 
    f = fs*(0:(L/2))/L; % frequencies 

    P2 = abs(Y/L); %2-sided magnitude spectrum
    P1 = P2(1:L/2+1); % single-sided magnitude spectrum 
    P1(2:end-1) = 2*P1(2:end-1);
    P = 10*log10(P1.^2); % single sided power spectrum
    
%%%% 3.a TO DO %%%%%%%%%
    % calculate average power or magnitude within the
    % range of frequencies you identified previously
    % avg_mag = ?; or avg_pwr = ?

%%%% 3.b TO DO %%%%%%%%%
    % classify as open or closed depending on threshold 
%     if avg_mag >= threshold 
%         flag = ?; 'C' or 'O'
%     end
%     if avg_mag < threshold
%         flag = ?; 'C' or 'O'
%     end
    %%%%%%%%%%%%%%%%%%%
    
set{2,i} = flag; 
    
end

classified_dataset = set; 

%%%% 3.c TO DO %%%%%%%%%%
% when looking at the training data, compare your classified_dataset to the
% labels in EyesOpenClosed_Training to see how you're doing. If there is
% poor classification, try changing frequency range or threshold 

%%%% 3.d TO DO %%%%%%%%%%
% Once satisfied (>80% classification accuracy), apply your classification 
% to the testing data EyesOpenClosed_Test.mat 

%%%% 3.f TO DO %%%%%%%%%%
% Plot the concatenated signal of the testing data and overlay a square wave that shows portion
% of C vs O. Makre sure the x-axis represents time not number of sample


